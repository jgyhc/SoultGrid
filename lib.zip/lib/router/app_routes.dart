// app_routes.dart
// part of 'app_pages.dart';

abstract class AppRoutes {
  static const index = "/";
  static const soult = "/soult";
}
