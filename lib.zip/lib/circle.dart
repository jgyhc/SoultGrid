import 'package:flutter/material.dart';

class PointData extends ChangeNotifier {
  double value = 0;
  void push(double p) {
    value = p;
    notifyListeners();
  }

  void clear() {
    notifyListeners();
  }
}

class ShapePainter extends CustomPainter {
  // final Animation<double> factor;
  final PointData point;
  ShapePainter(this.point) : super(repaint: point);
  @override
  void paint(Canvas canvas, Size size) {
    Paint paint = Paint()..color = Colors.red;
    canvas.drawCircle(Offset(10, 10 + (point.value * 80)), 10, paint);
  }

  @override
  bool shouldRepaint(covariant ShapePainter oldDelegate) {
    return false;
  }
}

class CirclePage extends StatefulWidget {
  @override
  _CirclePageState createState() => _CirclePageState();
}

class _CirclePageState extends State<CirclePage>
    with SingleTickerProviderStateMixin {
  AnimationController? _ctrl;
  Animation<double>? curveAnim; // 1.定义曲线动画
  PointData point = PointData();
  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this,
        reverseDuration: Duration(seconds: 2),
        duration: Duration(seconds: 2))
      ..addListener(_update);
    // ..fling(
    //     velocity: 10,
    //     springDescription: SpringDescription.withDampingRatio(
    //         mass: 1.0, stiffness: 500.00, ratio: 3.0));
    curveAnim = CurvedAnimation(parent: _ctrl!, curve: Curves.bounceOut);
    _ctrl?.forward();
    // _ctrl?.repeat(reverse: true);
  }

  void _update() {
    point.push(Curves.bounceOut.transform(_ctrl!.value));
    print(point.value.toString());
    // if (_ctrl!.value == 1) {
    //   _ctrl!.reverse();
    // }
    // setState(() {});
  }

  @override
  void dispose() {
    // 1. 销毁动画器
    _ctrl!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: Color.lerp(Colors.red, Colors.blue, 0.4)),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: CustomPaint(
          //<--- 使用绘制组件
          size: Size(100, 100),
          painter: ShapePainter(point),

          // painter: ShapePainter(color: Colors.red),  //<--- 设置画板
        ),
      ),
    );
  }
}
